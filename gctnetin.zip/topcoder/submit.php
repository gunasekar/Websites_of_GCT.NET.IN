<?php 
	require_once 'config/dbconfig.php';
	require_once 'config/php_functions.php';
	session_start();
	$msg = NULL;
	$msg = "Contest Ended!";
	if(!isset($_SESSION['id']))
	header('Location: index.php');
	if(isset($_POST['submit']) && $_POST['submit'] == "Submit" && !$msg){
		if(isset($_FILES["file"])){
		if ($_FILES["file"]["error"] > 0){
			$msg = "Error: " . $_FILES["file"]["error"];
		}
		else{
			$id = $_SESSION['id'];
			$pid = $_POST['pid'];
			$type = $_POST['ftype'];
			if($type == 11) 
			$filename = $id."p".$pid.".c";
			else if($type == 1) 
			$filename = $id."p".$pid.".cpp";
			else if($type == 10) 
			$filename = $id."p".$pid.".java";
			else if($type == 35) 
			$filename = $id."p".$pid.".js";
			else if($type == 29) 
			$filename = $id."p".$pid.".php";
			else if($type == 4 || $type == 116) 
			$filename = $id."p".$pid.".py";
			else if($type == 3 || $type == 54) 
			$filename = $id."p".$pid.".pl";
			else if($type == 17) 
			$filename = $id."p".$pid.".ruby";
			else
			$msg = "Invalid File Format!";
			if(!$msg){
				chdir("tc_codes");
				if(is_dir("$id")){
					move_uploaded_file($_FILES["file"]["tmp_name"],$dir = $id."/".$filename);
				}
				else{
					$dir = "".$id;
					mkdir($dir);
					move_uploaded_file($_FILES["file"]["tmp_name"],$dir = $id."/".$filename);
				}
				$dir = $id."/".$filename;
				
				//Code Evaluation by ideone starts
				$user = 'infoquest';
				$passwd = 'csita_iq';
				// creating soap client
				$client = new SoapClient("http://ideone.com/api/1/service.wsdl");
				// calling test function
				if(file_exists($dir) && filesize($dir) > 0){
					$handle = fopen($dir, "r");
					$code = fread($handle, filesize($dir));
					fclose($handle);
				}
				chdir("../");
				$dir = "problems/".$pid."/in";
				if(file_exists($dir) && filesize($dir) > 0){
					$handle = fopen($dir, "r");
					$input = fread($handle, filesize($dir));
					fclose($handle);
				}
				$dir = "problems/".$pid."/out";
				if(file_exists($dir) && filesize($dir) > 0){
					$handle = fopen($dir, "r");
					$output = fread($handle, filesize($dir));
					fclose($handle);
				}
				$run = true;
				$private = true;
				$language = $type;
				$time_limit = 0;
				$submit = $client->createSubmission($user, $passwd, $code, $language, $input, $run, $private);
				//var_dump($submit); echo "<br>";
				if($submit['error']=="OK"){
					$result = $client->getSubmissionStatus($user, $passwd, $submit['link']);
					while ( $result['status'] != 0 ) {
						if($time_limit == 30)
						$msg = "Server Load => Timed Out! Try submitting again!";
						sleep(3);
						$time_limit+=3;
						$result = $client->getSubmissionStatus( $user, $passwd, $submit['link'] );
					}
					if($result['status'] == 0){
						$details = $client->getSubmissionDetails( $user, $passwd, $submit['link'], true, true, true, true, true );
						if ( $details['error'] == 'OK' ) {
							//var_dump( $details );
							if($details['result'] != 15 || $details['result'] == 15 && $details['output'] == $output){
								$exec_time = $details['time'];
								$memory = $details['memory'];
								if($exec_time > 10)
								$value = 13;
								else
								$value = $details['result'];
							}
							else
								$value = 10;
						}
						else {
							$msg = "Error in submission!";
							$value = 0;
						}
					}
					else
					$value = $result['result'];
				}
				//Code Evalutation Complete
				if(!$msg){
					if($value == 15){
						$result = mysql_query("SELECT p$pid, score from topcoders WHERE  topcoder_id =$id");
						$p = 'p'.$pid;
						$update = mysql_result($result, 0, $p);
						$score = mysql_result($result, 0, 'score');
						if($update!=15)
						$score = $score + 15;
						$result = mysql_query("UPDATE  topcoders SET  p$pid =  $value, score = $score WHERE  topcoder_id =$id");
					}
					else
					$result = mysql_query("UPDATE  topcoders SET  p$pid =  $value WHERE  topcoder_id =$id");
					if($value == 0)
					$pad = "No Submissions Till Now<br>";
					else if($value == 10)
					$pad = "<img src='images/w.gif'> - Wrong Answer<br>";
					else if($value == 11)
					$pad = "<img src='images/w.gif'> - Compile Time Error<br>";
					else if($value == 12)
					$pad = "<img src='images/w.gif'> - Run Time Error<br>";
					else if($value == 13)
					$pad = "<img src='images/w.gif'> - Time Limit Exceeded<br>";
					else if($value == 17)
					$pad = "<img src='images/w.gif'> - Memory Limit Exceeded<br>";
					else if($value == 19)
					$pad = "<img src='images/w.gif'> - Illegal System Call<br>";
					else if($value == 20)
					$pad = "<img src='images/w.gif'> - Internal Error. Try Submitting Again!<br>";
					else{
					$pad = "<img src='images/r.gif'> - Solved!<br>";
					}
					$msg = "Submission result for Problem ID $pid : $pad";
				}
			}
			}
		}
	    }
	mysql_close($link);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

    <!--head-->
    <head profile="http://gmpg.org/xfn/11">
        <title>TopCoder - An Online Programming Contest By GCT CSITA</title>

        <link rel="pingback" href="http://ssq12.gct.net.in" />
        <link rel="shortcut icon" href="favicon.ico" />

   		<style type="text/css" media="all">
		@import "style.css";
		@import "sidebox.css";
		</style>

		<script language="JavaScript" src="js/gen_validatorv4.js" type="text/javascript"></script>
		<script src="js/jquery.js" type="text/javascript"></script>
		<script src="js/fusion.js" type="text/javascript"></script>

        
        <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    </head>
    <!--/head-->

    <!--body-->
	<body class="home">

    	<!-- page wrappers (100% width) -->
        <div id="page-wrap1">
            <div id="page-wrap2">

            <!-- page (actual site content, custom width) -->
            <div id="page" class="with-sidebar">

                <!-- main wrapper (side & main) -->
                <div id="main-wrap">
                <!-- mid column wrap -->
                <div id="mid-wrap">
                <!-- sidebar wrap -->
                <div id="side-wrap">
                
                <!-- mid column -->
                <div id="mid">
                    <!-- header -->
					<div id="header">
						<div id="topnav"><p><a href=".">Home</a> | <a href="peer_coders.php">Peer Coders</a> | <a href="forum.php">User Forum</a>| <a href="show.php?page=a">About</a></p></div>
						<h1 id="logo"><a href=".">TopCoder</a></h1>
						<!-- top tab navigation -->
						<div id="tabs">
							<ul>
							<li><a href="index.php"><span><span>To TopCoder</span></span></a></li>
							<li><a href="problems.php"><span><span>Problems</span></span></a></li>
							<li><a href="submit.php" class="active"><span><span>Submit your Solutions</span></span></a></li>
							</ul>
						</div>
						<!-- /top tabs -->
					</div>
                    <!-- /header -->
                    <!-- mid content -->
                    <div id="mid-content">
                        <!-- content -->
                        <div align="center"><font size="3"><strong>Submissions</strong></font><br><br></div>
                        <div align="center">
                        <script>
						function process() {
							  $('#showprogress').html('<p>Evaluating...<br><img src="images/cprogress.gif" /></p>');
							}
						</script>
						<div id="showprogress">
						<?php
							if($msg)
							echo "<strong>$msg</strong><br><br><br>";
							else{
						?>
						</div>
                        <form action="submit.php" method="post" enctype="multipart/form-data" name="submitForm" id="submitForm">
                        <p>
                            Problem ID
                            <select name="pid" id="pid">
                            <option value="1" selected="selected">Problem ID 1</option>
                            <option value="2">Problem ID 2</option>
                            <option value="3">Problem ID 3</option>
                            <option value="4">Problem ID 4</option>
                            <option value="5">Problem ID 5</option>
                            </select><br><br>
	                      </p>
	                      <p>
                            Source Code Type
                            <select name="ftype" id="ftype">
								<option value="11" selected="selected">C (gcc-4.3.4)</option>
								<option value="1">C++ (gcc-4.3.4)</option>
								<option value="10">Java (sun-jdk-1.6.0.17)</option>
								<option value="35">JavaScript (rhino) (rhino-1.6.5)</option>
								<option value="112">JavaScript (spidermonkey) (spidermonkey-1.7)</option>
								<option value="3">Perl (perl 5.12.1)</option>
								<option value="54">Perl 6 (rakudo-2010.08)</option>
								<option value="29">PHP (php 5.2.11)</option>
								<option value="4">Python (python 2.6.4)</option>
								<option value="116">Python 3 (python-3.1.2)</option>
								<option value="17">Ruby (ruby-1.9.2)</option>
							</select><br><br>
	                      </p>
									<label for="file">Source Code:</label>
									<input type="file" name="file" id="file" /> 
									<br />
									<input type="submit" onclick="process()" name="submit" value="Submit" />
									<div id="submitForm_errorloc" class="error_strings"></div>
									</form>
                        <script language="JavaScript" type="text/javascript">
                            var frmvalidator  = new Validator("submitForm");
                            frmvalidator.EnableOnPageErrorDisplaySingleBox();
                            frmvalidator.EnableMsgsTogether();
                            frmvalidator.addValidation("file","req_file","File upload is required");
                        </script>
                            </div>
                            <?}?>
                        <!-- /content-->
                        </div>
                        <!-- /mid content -->
                    </div>
					<!-- /mid -->

                    <!-- sidebar -->
                    <div id="sidebar">
                        <!-- sidebar 1st container -->
                        <div id="sidebar-wrap1">
                        <!-- sidebar 2nd container -->
                        <div id="sidebar-wrap2">
                            <ul id="sidelist">
                            <h3>Sidebar</h3>
                                <?php
                                    include "u_sidebar.php"
                                ?>
                                <!-- login -->
                                <li class="box">
                                    <h3 class="title">
                                    <?php
                                    if(!isset($_SESSION['id']))
                                        echo "Login";
                                    else
                                        echo "User Status";
                                    ?>
                                    </h3>

                                <div id="loginblock">
                                <?php
                                        if(!isset($_SESSION['id'])){
                                        	?>
                                        	<form action='index.php' method='post' name='logForm' id='logForm' >

                                                <p>Topcoder ID/Name<br />
                                                        <input type='text' name='loginid' class='login'/>
                                                </p>

                                                <p>Password<br />
                                                        <input type='password' name='pwd' class='login'/>
                                                </p>

                                                <p>
                                                        <input name='doLogin' type='submit' id='doLogin' value='Login'>
                                                </p>
                                                
                                                <p>
																<div align='center'>New User? <a href='register.php'>Click here!</a></div><br>
                                                </p>
                                                <div id="r_copy"><div id="logForm_errorloc"></div></div>
                                                </form>
                                        <script language="JavaScript" type="text/javascript">
                                        var frmvalidator  = new Validator("logForm");
                                        frmvalidator.EnableOnPageErrorDisplaySingleBox();
                                        frmvalidator.EnableMsgsTogether();   

                                        frmvalidator.addValidation("loginid","req","Please enter your user id");
                                        frmvalidator.addValidation("loginid","maxlen=30","Maximum length for TopCoder ID is 30");
                                        frmvalidator.addValidation("loginid","minlen=6","Minimum length for TopCoder ID is 6");

                                        frmvalidator.addValidation("pwd","req","Please enter your password");
                                        frmvalidator.addValidation("pwd","minlen=5","Min length for password is 5");
                                        </script>
                                                <?
                                        }
                                        else{
                                                echo "Hi, You are logged in as  ", $_SESSION['name'];
                                                echo "<br><p><a href='logout.php'>Logout</a></p>";
                                        }
                                    ?>
                                    </div>
                                </li>
                                <!-- /login -->
                            </ul>
                        </div>
                        <!-- /sidebar 2nd container -->
                        </div>
                        <!-- /sidebar 1st container -->
                    </div>
                    <!-- /sidebar -->

				</div>
                <!-- /side wrap -->
                </div>
                <!-- /mid column wrap -->
                </div>
                <!-- /main wrapper -->

                <!-- clear main & sidebar sections -->
                <div class="clearcontent"></div>
                <!-- /clear main & sidebar sections -->

                <!-- footer -->
                <div id="footer">
    	            <p>GCT CSITA - iTeam<br>TopCoder uses <a href="http://ideone.com" target="_blank">Ideone API</a> &copy; by <a href="http://sphere-research.com" target="_blank">Sphere Research Labs</a></p>
                </div>
                <!-- /footer -->
                
                <!-- layout controls -->
                <div id="layoutcontrol">
        	        <a href="javascript:void(0);" class="setFont" title="Increase/Decrease text size"><span>SetTextSize</span></a>
            	    <a href="javascript:void(0);" class="setLiquid" title="Switch between full and fixed width"><span>SetPageWidth</span></a>
                </div>
                <!-- /layout controls -->
               
            </div>
            <!-- /page -->
        </div>
        </div>
        <!-- /page wrappers -->
	
	</body>
</html>
