<?php
echo "1\n3\n";
?>
