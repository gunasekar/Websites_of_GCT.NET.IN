<marquee>
<h2 align = 'center'><strong>Workshop went succesfully on 29th February! Get the review from your friends who have attended...</strong></h2><br>
</marquee>
<div align="center"><h3><strong>Workshop on Network Security and Ethical Hacking</strong></h3><br>
<h2>hackQ workshop will be conducted as a fast track program for 3 hours on 2nd March, 2012</h2><br><br>
Conducted by<br>
<strong>Dr. T. Purusothaman M.E., Ph.D.</strong><br>
Assistant Professor (R.D)<br>
Area of interest – Network Security, Distributed computing and Cryptanalysis.<br>
<h3><strong>Date : 2nd March, 2012 / 3 Hour Program starts by 2PM<br>Registrations are limited for this program!<br>Spot Registrations in the morning along with IQ registration</strong><br><strong>Registration Fees - Rs. 200</strong><br></h3><br><br>
<strong>Certificates will be provided by Govt. College of Technology, Coimbatore<br>Training Materials, Resources will be provided!</strong><br><br><br>
<h3><strong>Contact Details</strong></h3>
Saravanan. R - 9942534917<br>
Petchimuthu - 9952859356<br>
Organising Secretaries<br>
Workshop on Ethical Hacking<br>
Dept. of CSE and IT<br>
Govt. College of Technology, Coimbatore - 641013<br><br><br>
For further Details<br>
Mail to : <a href="mailto:infoquest@gct.net.in">infoquest@gct.net.in</a><br>
</div>
