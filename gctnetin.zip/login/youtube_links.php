<a href='http://dl.dropbox.com/u/53931831/blossom11.pdf'><h2 align='center'>Blossom'11 Magazine for Download!</h2></a>
<br>
<h2>InfoQuest'12 Trailor</h2>
<iframe width="475" height="320" src="http://www.youtube.com/embed/eUH6QNT8vq4" frameborder="0" allowfullscreen></iframe>
<br>
<h2>Login'11 Promo-1!</h2>
<iframe width="475" height="320" src="http://www.youtube.com/embed/Q7Fb8X0WpoQ" frameborder="0" allowfullscreen></iframe>
<br>
<h2>Login'11 Promo-2!</h2>
<iframe width="475" height="320" src="http://www.youtube.com/embed/ql-YKjQ0xtk" frameborder="0" allowfullscreen></iframe>
<br>
<h2>Inauguration Flick</h2>
<iframe width="475" height="320" src="http://www.youtube.com/embed/KhMAC_2tRck" frameborder="0" allowfullscreen></iframe>
<br>
<h2>Cultural Inauguration</h2>
<iframe width="475" height="320" src="http://www.youtube.com/embed/dha3X3ttBUA" frameborder="0" allowfullscreen></iframe>
<br>
<h2>Evandi Unna Pethan</h2>
<iframe width="475" height="320" src="http://www.youtube.com/embed/WcWAlviZ1LA" frameborder="0" allowfullscreen></iframe>
<br>
<h2>Obey Road Rules</h2>
<iframe width="475" height="320" src="http://www.youtube.com/embed/IcaTnvuSoNc" frameborder="0" allowfullscreen></iframe>
