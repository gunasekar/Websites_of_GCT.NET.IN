<?php
    require_once 'config/dbconfig.php';
    require_once 'config/php_functions.php';
    logout();
    mysql_close($link);
?> 