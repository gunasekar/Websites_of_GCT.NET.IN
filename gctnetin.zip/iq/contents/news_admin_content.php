<form action="contents/news_insert.php" method="post">
	<p><h2>Enter News Updates</h2><br>
	<textarea name='content'rows=5 cols=35></textarea>
	</p>
	<p>
	<input type="submit" name="submit" value="Submit"/>
	</p>
</form>
