<li>
    <!-- sidebar menu (categories) -->
    <ul class="nav">
        <!-- sidebar menu 1-->
        <li class="cat-item">
        <h6>Contest ended!</h6>
            <br>
        </li>
        <li class="cat-item">
            <a href="user_stat.php" class="active"><span>Submission Status</span></a><a  class="rss tip" href="user_stat.php"></a>
        </li>
        <!-- sidebar menu 2-->
        <li class="cat-item">
        <a href="#" class="active"><span>Guidelines</span></a><a  class="rss tip" href="#"></a>
            <ul>
                <!-- sidebar sub-menu 1-->
                <li class="cat-item">
                    <a href="show.php?page=p"><span>Programming Guidelines</span></a><a  class="rss tip" href="show.php?page=p"></a>
                </li>
                <!-- sidebar sub-menu 2-->
                <li class="cat-item">
                    <a href="show.php?page=s"><span>Submission Guidelines</span></a><a  class="rss tip" href="show.php?page=s"></a>
                </li>
            </ul>
        </li>
    </ul>
    <!-- /sidebar menu -->
</li>
