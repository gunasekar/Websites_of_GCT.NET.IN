<h2>Login for an Ultimate Entertainment!</h2>
<br>
<h3>IQ'12 Trailor</h3><br>
<iframe width="475" height="320" src="http://www.youtube.com/embed/eUH6QNT8vq4" frameborder="0" allowfullscreen></iframe>
<br>
<p>	
A Non-Technical episode of the Computer Science and Engineering & Information Technology Association at Government College of Technology, Coimbatore.<br>
Apart from the technical erudition of the binarians, each and everyone have a distinct flank where we prove our profligacy. The sole idea of this event is to twinge that distinct quality from the proteges of CSITA.<br>
Get Ready to unearth the special assortment on 24th December'11
</p>
<br>
<a href='http://dl.dropbox.com/u/53931831/blossom11.pdf'><h3 align='center'>Blossom'11 Magazine for Download!</h3></a>
<br>
