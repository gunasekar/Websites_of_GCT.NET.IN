<?php
    require_once 'contents/dbconfig.php';
    require_once 'contents/php_functions.php';
    logout();
?> 