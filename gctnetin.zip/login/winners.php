<ul>
	<li><h3>Treasure Hunt</h3>
		<ol>
		<li>Sathish Kumar</li>
		<li>Arun Kumar</li>
		<li>Amsaveni</li>
		</ol>
	</li>
	<li><h3>Cine Quiz</h3>
		<ol>
		<li>Vasanth</li>
		<li>Subramani</li>
		</ol>
	</li>
	<li><h3>Marketing</h3>
		<ol>
		<li>Shri Vishnu</li>
		<li>Loga Sowmya</li>
		</ol>
	</li>
	<li><h3>General Quiz</h3>
		<ol>
		<li>Suren</li>
		<li>Ramya</li>
		</ol>
	</li>
	<li><h3>Musical Chair</h3>
		<ol>
		<li>Yogaraj</li>
		</ol>
	</li>
	<li><h3>Cricket</h3>
		<ol>
		<li>Gryffindors</li>
		</ol>
	</li>
	<li><h3>Chess</h3>
		<ol>
		<li>Ashwin. M</li>
		</ol>
	</li>
	<li><h3>Carrom</h3>
		<ol>
		<li>Ashwin. R</li><li>Arun</li>
		</ol>
	</li>
	<li><h3>Volley Ball</h3>
		<ol>
		<li>Gryffindors</li>
		</ol>
	</li>
	<br><hr>
	<li><h3><a href="http://topcoder.gct.net.in/login11/">Online Programming Event</a></h3></li>
	<br><hr>
	<li><h3><a href="https://www.facebook.com/pages/Login11/242129555857076">Online Photography Event at FB</a></h3></li>
</ul>
