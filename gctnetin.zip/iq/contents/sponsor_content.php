<h6>Main/Title Sponsor</h6>
<a href="http://www.tcs.com/" target=_blank><img src="images/sponsors/tcs.jpg"></a><br><br>
<h6>Local Sponsors</h6>
<table>
	<tr>
		<td><img src="images/sponsors/connect.jpg" width="300" height="250"></td>
		<td><img src="images/sponsors/sakthi.png" width="300" height="250"></td>
	</tr>
	<tr>
		<td><img src="images/sponsors/rsninfo.jpg" width="300" height="250"></td>
		<td><img src="images/sponsors/caresoft.jpg" width="300" height="250"></td>
	</tr>
</table>
<br>
<h6>Online Promotional Partners</h6>
<table>
	<tr>
		<td><a href="http://www.twenty19.com/" target=_blank><img src="images/sponsors/twenty19.jpg" width="300" height="300"></a></td>
		<td><a href="http://www.symposiumz.net/" target=_blank><img src="images/sponsors/symposiumz.jpg" width="300" height="300"></a></td>
	</tr>
	<tr>
		<td><a href="http://www.collegekhabar.com/" target=_blank><img src="images/sponsors/ck.jpg" width="200" height="100"></a></td>
		<td><a href="http://www.eventsfeeder.com/" target=_blank><img src="images/sponsors/ef.jpg" width="200" height="100"></a></td>
	</tr>
</table>
<br><br><hr>
<h5>For any Sponsorships/advertisements, Please contact our Marketing Managers!</h5>
