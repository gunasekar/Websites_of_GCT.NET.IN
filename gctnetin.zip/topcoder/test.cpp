#include<iostream>
using namespace std;
int main(){
	int i, j;
    cin>>i;
    while(i--){
		cin>>j;
        cout<<j<<endl;
    }
    return 0;
}
