<?php
    require_once 'config/dbconfig.php';
    $result = mysql_query("UPDATE topcoders SET `p1` = 0, `p2` = 0, `p3` = 0, `p4` = 0, `p5` = 0, `score` = 0"); 
?>
