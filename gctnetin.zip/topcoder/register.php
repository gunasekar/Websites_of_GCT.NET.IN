<?php
	session_start();
	if(!isset($_SESSION['id'])){
		session_destroy();
    require_once 'config/dbconfig.php';
    require_once 'config/php_functions.php';
    $msg = NULL;
    if(isset($_GET['status']) && $_GET['status'] == 'done')
        $msg = "<h3>Thank you!</h3><br>
                <h6>Your registration is now complete!</h6>
                <p>An activation email has been sent to your and partner's(if applicable) email address(es). Click on the activation link for activating your account.<br><br>
                <strong>Please don't forget to check your spam folder</strong><br><br></font></p>";
    if(isset($_POST['doRegister']) && $_POST['doRegister'] == 'Register' && !$msg) {
    	if(isset($_POST['m1']) && isset($_POST['pwd']) && isset($_POST['c_pwd'])){
            foreach($_POST as $key => $value) {
                    $data[$key] = filter($value);
            }
            
            /********************* RECAPTCHA CHECK *******************************
            This code checks and validates recaptcha
            ****************************************************************/
            /*require_once('recaptchalib.php');

            $resp = recaptcha_check_answer($privatekey,
                                          $_SERVER["REMOTE_ADDR"],
                                          $_POST["recaptcha_challenge_field"],
                                          $_POST["recaptcha_response_field"]);
            if (!$resp->is_valid) {
            $err[]  = "ERROR - Image Verification failed! Try Again!";
            }*/
            
            /************************ SERVER SIDE VALIDATION **************************************/
            /********** This validation is useful if javascript is disabled in the browswer ***/

            // Validate User Name
            if (!isUserName($data['name'])) {
                $msg = $msg."<br>ERROR - Invalid user name. It can contain only alphabets with atleast 5 characters.";
            }

            // Check User Passwords
            if (!checkPwd($data['pwd'],$data['c_pwd'])) {
                $msg = $msg."<br>ERROR - Invalid Password or mismatch. Enter 5 chars or more";
            }
				$primary = $_POST['m1'];
				if(substr($primary, 0, 2) == "iq" || substr($primary, 0, 2) == "IQ" || substr($primary, 0, 2) == "Iq" || substr($primary, 0, 2) == "iQ")
					$primary = substr($primary, 2);
				else
					$msg = "Invalid ID";
				$p_flag = 0;
				if(isset($_POST['m2']) && strlen($_POST['m2']) > 0){
					$partner = $_POST['m2'];
					if(substr($partner, 0, 2) == "iq" || substr($partner, 0, 2) == "IQ" || substr($partner, 0, 2) == "Iq" || substr($partner, 0, 2) == "iQ"){
						$p_flag = 1;
						$partner = substr($partner, 2);
					}
					else
						$msg = "Invalid IQ ID";
				}
				
				if(!$user_registration)
				$msg = "Registration is not yet open";
				
				if(!$msg){
					if($p_flag){
						$result = mysql_query("select user_email from users, e_reg where users.id=$primary and e_reg.id =$primary and e_reg.e_1 = 1") or die(mysql_error());
						$count = mysql_num_rows($result);
						if($count>=1){
							$email1 = mysql_result($result, 0, 'user_email');
							$result = mysql_query("select user_email from users, e_reg where users.id=$partner and e_reg.id =$partner and e_reg.e_1 = 1") or die(mysql_error());
							$count = mysql_num_rows($result);
							if($count>=1)
							$email2 = mysql_result($result, 0, 'user_email');
							else
								$msg = "Invalid IQ ID or User not registered for TopCoder event. Check out the Events page in IQ Site for on-line events registrations after signing in!";  
						}
						else
							$msg = "Invalid IQ ID or User not registered for TopCoder event. Check out the Events page in IQ Site for on-line events registrations after signing in!";  
					}
					else{
						$result = mysql_query("select user_email from users, e_reg where users.id=$primary and e_reg.id =$primary and e_reg.e_1 = 1") or die(mysql_error());
						$count = mysql_num_rows($result);
						if($count>=1)
						$email1 = mysql_result($result, 0, 'user_email');
						else
							$msg = "Invalid IQ ID or User not registered for TopCoder event. Check out the Events page in IQ Site for on-line events registrations after signing in!";  
					}
					if($p_flag)
					$result = mysql_query("select count(*) as total from tc_register where id=$primary or id=$partner") or die(mysql_error());
					else
					$result = mysql_query("select count(*) as total from tc_register where id=$primary") or die(mysql_error());
					list($total) = mysql_fetch_row($result);
	
	            if ($total > 0){
	                $msg = $msg."<br>ERROR - Member(s) of this registering team has/have already registered in another team";
	            }
            }
            if(!$msg){
	            // stores sha1 of password
	            $pwd = PwdHash($data['pwd']);
	
	            // Automatically collects the hostname or domain  like example.com) 
	            $host  = $_SERVER['HTTP_HOST'];
	            $host_upper = strtoupper($host);
	            $path   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	
	            // Generates activation code simple 4 digit number
	            $activ_code = rand(1000,9999);
	
	            $team_name = mysql_real_escape_string($data['name']);
	            
	            $rs_duplicate = mysql_query("select count(*) as total from topcoders where name='$team_name'") or die(mysql_error());
	            list($total) = mysql_fetch_row($rs_duplicate);
	
	            if ($total > 0){
	                $msg = $msg."<br>ERROR - The team name already registered. Please try again with different name.";
	            }
				
	            if(!$msg) {
			              //Inserting in topcoders table
	                    $sql_insert = "INSERT INTO topcoders (`name`, `pwd`, `activation_code`) VALUES ('$team_name', '$pwd', '$activ_code');";
	                    mysql_query($sql_insert,$link) or die("Insertion Failed:" . mysql_error());
	                    $id = mysql_insert_id($link);
	                    //Inserting in tc_register table	                    
	                    $sql_insert = "INSERT INTO tc_register (`id`, topcoder_id) VALUES ('$primary', '$id');";
	                    mysql_query($sql_insert,$link) or die("Insertion Failed:" . mysql_error());
	                    if($p_flag){
		                    $sql_insert = "INSERT INTO tc_register (`id`, topcoder_id) VALUES ('$partner', '$id');";
		                    mysql_query($sql_insert,$link) or die("Insertion Failed:" . mysql_error());
	                    }
	                    if($user_registration){
	                        $a_link = "*****Here is your ACTIVATION LINK*****\n
	http://$host$path/activate.php?id=$id&activ_code=$activ_code";
	                    } else {
	                        $a_link = "Your account is *PENDING FOR APPROVAL* and will be soon activated by the administrator.";
	                    }
	                    $message = 
"Hello $team_name !\n
Thank you for registering with TopCoder - GCT CSITA. Here are your login details...\n

TopCoder ID: TC$id\n
Team Name: $team_name \n
Team Password: $data[pwd] \n

$a_link

Thank You!

Administrator
TopCoder - GCT CSITA
______________________________________________________
THIS IS AN AUTOMATED RESPONSE. 
***DO NOT RESPOND TO THIS EMAIL****
";
	
	                    mail($email1, "TopCoder Login Details", $message, "From: \"TopCoder @ GCT.NET.IN\" <auto-reply@$host>\r\n" . "X-Mailer: PHP/" . phpversion());
	                    mail($email2, "TopCoder Login Details", $message, "From: \"TopCoder @ GCT.NET.IN\" <auto-reply@$host>\r\n" . "X-Mailer: PHP/" . phpversion());
	
	                    header("Location: register.php?status=done");
	                    exit();
	            }
	            else
	                $msg = $msg."<br><a href='register.php'>Registration Form</a>";
          }
    }
    else
    $msg = "Invalid Inputs! Try again...<br><a href='register.php'>Registration Form</a>";
    }
    }
    else {
    	header('Location: index.php');
    	}
    	mysql_close($link);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

	<!--head-->
		<head profile="http://gmpg.org/xfn/11">
			<title>Registration - TopCoder</title>

			<link rel="pingback" href="http://ssq12.gct.net.in" />
			<link rel="shortcut icon" href="favicon.ico" />

			<style type="text/css" media="all">
			  @import "style.css";
			  @import "sidebox.css";
			</style>
			<script language="JavaScript" src="js/gen_validatorv4.js" type="text/javascript"></script>
			<script src="js/jquery.js" type="text/javascript"></script>
			<script src="js/fusion.js" type="text/javascript"></script>
			<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
		</head>
	 <!--/head-->

    <!--body-->
	<body class="home">

    	<!-- page wrappers (100% width) -->
        <div id="page-wrap1">
		<div id="page-wrap2">

            <!-- page (actual site content, custom width) -->
			<div id="page" class="with-sidebar">

				<!-- main wrapper (side & main) -->
				<div id="main-wrap">
                        <!-- mid column wrap -->
				<div id="mid-wrap">
                                <!-- sidebar wrap -->
				<div id="side-wrap">
                
                    <!-- mid column -->
                    <div id="mid">
                    <!-- header -->
								<div id="header">
									<div id="topnav"><p><a href=".">Home</a> | <a href="peer_coders.php">Peer Coders</a> | <a href="forum.php">User Forum</a>| <a href="show.php?page=a">About</a></p></div>
									<h1 id="logo"><a href=".">TopCoder</a></h1>
									<!-- top tab navigation -->
									<div id="tabs">
										<ul>
										<li><a href="index.php"><span><span>To TopCoder</span></span></a></li>
										<li><a href="problems.php"><span><span>Problems</span></span></a></li>
										<li><a href="submit.php"><span><span>Submit your Solutions</span></span></a></li>
										</ul>
									</div>
									<!-- /top tabs -->
								</div>

                                <!-- /header -->

                                <!-- mid content -->
                       <div id="mid-content" align="center">
								<h3>TopCoder Team Registration</h3>
								<?php
									if(isset($_GET['status']) && $_GET['status'] == 'done');
									else{
								?>
								Registering team members will individually receive an activation mail. Anyone of the team members has to activate in the team account to start participating in the contest.<br>
								<form action='register.php' method='post' name='regForm' id='regForm' >
									<table>
										<tr>
											<td>TopCoder Team Name : </td><td><input type="text" name="name"/></td>
										</tr>
										<tr>
											<td>Primary Member- IQ ID *:</td><td><input type='text' name='m1'/></td>
										</tr>
										<tr>
											<td>Partner - IQ ID:</td><td><input type='text' name='m2'/></td>
										</tr>
										<tr>
											<td>TopCoder Team Password : </td><td><input type='password' name='pwd'/></td>
										</tr>
										<tr>
											<td>Confirm Password : </td><td><input type='password' name='c_pwd'/></td>
										</tr>
										</table>
										<input type="submit" name="doRegister" value="Register"/>
										<div id="r_copy"><div id="regForm_errorloc"></div></div>
                           </form>
												<script language="JavaScript" type="text/javascript">
												var frmvalidator  = new Validator("regForm");
												frmvalidator.EnableOnPageErrorDisplaySingleBox();
												frmvalidator.EnableMsgsTogether();   

												frmvalidator.addValidation("name","req","Please enter your team name");
												frmvalidator.addValidation("name","maxlen=30","Maximum length for team name is 30");
												frmvalidator.addValidation("name","minlen=5","Minimum length for team name is 6");
												
												frmvalidator.addValidation("m1","req","Please enter your primary team member's IQ ID");
												frmvalidator.addValidation("m1","maxlen=6","Maximum length for IQ ID is 6");
												frmvalidator.addValidation("m1","minlen=6","Minimum length for IQ ID is 6");
												
												frmvalidator.addValidation("pwd","req","Please enter your Password");
												frmvalidator.addValidation("c_pwd","req","Please re-type your Password");
												frmvalidator.addValidation("c_pwd","eqelmnt=pwd","The retyped password is not same as password");
												frmvalidator.addValidation("pwd","neelmnt=name","The password should not be same as your name");
												frmvalidator.addValidation("pwd","maxlen=20","Maximum length for your password is 20");
												frmvalidator.addValidation("pwd","minlen=5","Minimum length for your password is 5");
												</script>
												<?}
												if($msg)
												echo "$msg<br>";
												?>
                                </div>
                                <!-- /mid content -->
                            </div>
                            <!-- /mid -->

                    <!-- sidebar -->
                    <div id="sidebar">
                        <!-- sidebar 1st container -->
                        <div id="sidebar-wrap1">
                        <!-- sidebar 2nd container -->
                        <div id="sidebar-wrap2">
                            <ul id="sidelist">
                            <h3>Sidebar</h3>
                            <?php
                            include "u_sidebar.php";
                            ?>
                                <li class="box">
                                    <h3 class="title">
                                    <?php
                                    if(!isset($_SESSION['id']))
                                        echo "User Login";
                                    else
                                        echo "User Status";
                                    ?>
                                    </h3>

                                    <div id="loginblock">
                                    <?php
                                            if(!isset($_SESSION['id'])){
                                                ?>
                                                <form action='index.php' method='post' name='logForm' id='logForm' >

                                                <p>Topcoder ID/Name<br />
                                                        <input type='text' name='loginid' class='login'/>
                                                </p>

                                                <p>Password<br />
                                                        <input type='password' name='pwd' class='login'/>
                                                </p>

                                                <p>
                                                        <input name='doLogin' type='submit' id='doLogin' value='Login'>
                                                </p>
                                                
                                                <p>
																<div align='center'>New User? <a href='register.php'>Click here!</a></div><br>
                                                </p>
                                                <div id="r_copy"><div id="logForm_errorloc"></div></div>
                                                </form>
                                        <script language="JavaScript" type="text/javascript">
                                        var frmvalidator  = new Validator("logForm");
                                        frmvalidator.EnableOnPageErrorDisplaySingleBox();
                                        frmvalidator.EnableMsgsTogether();   

                                        frmvalidator.addValidation("loginid","req","Please enter your user id");
                                        frmvalidator.addValidation("loginid","maxlen=30","Maximum length for TopCoder ID is 30");
                                        frmvalidator.addValidation("loginid","minlen=6","Minimum length for TopCoder ID is 6");

                                        frmvalidator.addValidation("pwd","req","Please enter your password");
                                        frmvalidator.addValidation("pwd","minlen=5","Min length for password is 5");
                                        </script>
												<?php
												}
												else{
													echo "Hi, You are logged in as  ", $_SESSION['name'];
													echo "<br><p><a href='logout.php'>Logout</a></p>";
												}
											?>
                                    </div>
                                </li>
                                <!-- /login -->
                            </ul>
                        </div>
                        <!-- /sidebar 2nd container -->
                        </div>
                        <!-- /sidebar 1st container -->
                    </div>
                    <!-- /sidebar -->

				</div>
                <!-- /side wrap -->
                </div>
                <!-- /mid column wrap -->
                </div>
                <!-- /main wrapper -->

                <!-- clear main & sidebar sections -->
                <div class="clearcontent"></div>
                <!-- /clear main & sidebar sections -->

                <!-- footer -->
                <div id="footer">
    	            <p>GCT CSITA - iTeam<br>TopCoder uses <a href="http://ideone.com" target="_blank">Ideone API</a> &copy; by <a href="http://sphere-research.com" target="_blank">Sphere Research Labs</a></p>
                </div>
                <!-- /footer -->
                
                <!-- layout controls -->
                <div id="layoutcontrol">
        	        <a href="javascript:void(0);" class="setFont" title="Increase/Decrease text size"><span>SetTextSize</span></a>
            	   <a href="javascript:void(0);" class="setLiquid" title="Switch between full and fixed width"><span>SetPageWidth</span></a>
                </div>
                <!-- /layout controls -->
               
            </div>
            <!-- /page -->
        </div>
        </div>
        <!-- /page wrappers -->
	
	</body>
</html>
