#include<stdio.h>
int main(){
	int i, j;
	scanf("%d", &i);
	while(i--){
	    scanf("%d", &j);
	    printf("%d", j+1);
	}
    return 0;
}
