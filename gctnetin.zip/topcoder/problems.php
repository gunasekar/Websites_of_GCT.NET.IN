<?php 
    require_once 'config/dbconfig.php';
    require_once 'config/php_functions.php';
    mysql_close($link);
    session_start();
	if(!isset($_SESSION['id']))
	header('Location: index.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

    <!--head-->
    <head profile="http://gmpg.org/xfn/11">
        <title>TopCoder - An Online Programming Contest By GCT CSITA</title>

        <link rel="pingback" href="http://ssq12.gct.net.in" />
        <link rel="shortcut icon" href="favicon.ico" />

			<style type="text/css" media="all">
			  @import "style.css";
			  @import "sidebox.css";
			</style>
			<script language="JavaScript" src="js/gen_validatorv4.js" type="text/javascript"></script>
			<script src="js/jquery.js" type="text/javascript"></script>
        <script src="js/fusion.js" type="text/javascript"></script>
        <script type="text/javascript">
			function loadXMLDoc(p_id){
				var xmlhttp;
				if (window.XMLHttpRequest){
					// code for IE7+, Firefox, Chrome, Opera, Safari
					xmlhttp=new XMLHttpRequest();
				}
				else{
					// code for IE6, IE5
					xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
				}
				xmlhttp.onreadystatechange=function(){
					if (xmlhttp.readyState==4 && xmlhttp.status==200){
						document.getElementById("problem_area").innerHTML=xmlhttp.responseText;
					}
				}
				switch(p_id){
					case 1:
					xmlhttp.open("GET","problems/1/statement",true);
					xmlhttp.send();
					break;
					case 2:
					xmlhttp.open("GET","problems/2/statement",true);
					xmlhttp.send();
					break;
					case 3:
					xmlhttp.open("GET","problems/3/statement",true);
					xmlhttp.send();
					break;
					case 4:
					xmlhttp.open("GET","problems/4/statement",true);
					xmlhttp.send();
					break;
					case 5:
					xmlhttp.open("GET","problems/5/statement",true);
					xmlhttp.send();
					break;
					default:
					xmlhttp.open("GET","problems/default",true);
					xmlhttp.send();
					}
				}
			</script>

        <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    </head>
    <!--/head-->

    <!--body-->
	<body class="home">

    	<!-- page wrappers (100% width) -->
        <div id="page-wrap1">
            <div id="page-wrap2">

            <!-- page (actual site content, custom width) -->
            <div id="page" class="with-sidebar">

                <!-- main wrapper (side & main) -->
                <div id="main-wrap">
                <!-- mid column wrap -->
                <div id="mid-wrap">
                <!-- sidebar wrap -->
                <div id="side-wrap">
                
                <!-- mid column -->
                <div id="mid">
                    <!-- header -->
                    <div id="header">
						<div id="topnav"><p><a href=".">Home</a> | <a href="peer_coders.php">Peer Coders</a> | <a href="forum.php">User Forum</a>| <a href="show.php?page=a">About</a></p></div>
						<h1 id="logo"><a href=".">TopCoder</a></h1>
						<!-- top tab navigation -->
						<div id="tabs">
							<ul>
							<li><a href="index.php"><span><span>To TopCoder</span></span></a></li>
							<li><a href="problems.php" class="active"><span><span>Problems</span></span></a></li>
							<li><a href="submit.php"><span><span>Submit your Solutions</span></span></a></li>
							</ul>
						</div>
						<!-- /top tabs -->
					</div>
                    <!-- /header -->
                    <!-- mid content -->
                    <div id="mid-content">
                        <!-- content -->
                        <a name='#show_problem'></a>
                        <div align="center"><font size="3"><strong>IQ'12 Problem Sets</strong></font></div>
                        <div id="problem_area">
                        <?php
								include "problems/default";
								?>
                        </div>
                        </div>
                        <!-- /mid content -->
                    </div>
					<!-- /mid -->

                    <!-- sidebar -->
                    <div id="sidebar">
                        <!-- sidebar 1st container -->
                        <div id="sidebar-wrap1">
                        <!-- sidebar 2nd container -->
                        <div id="sidebar-wrap2">
                            <ul id="sidelist">
                            <h3>Sidebar</h3>
                                <?php
                                    include "u_sidebar.php";
                                    include "problems_pane.html";
                                ?>
                                <!-- login -->
                                <li class="box">
                                    <h3 class="title">
                                    <?php
                                    if(!isset($_SESSION['id']))
                                        echo "Login";
                                    else
                                        echo "User Status";
                                    ?>
                                    </h3>

                                <div id="loginblock">
                                <?php
                                        if(!isset($_SESSION['id'])){
                                   ?>
                                                <form action='index.php' method='post' name='logForm' id='logForm' >

                                                <p>Topcoder ID/Name<br />
                                                        <input type='text' name='loginid' class='login'/>
                                                </p>

                                                <p>Password<br />
                                                        <input type='password' name='pwd' class='login'/>
                                                </p>

                                                <p>
                                                        <input name='doLogin' type='submit' id='doLogin' value='Login'>
                                                </p>
                                                
                                                <p>
																<div align='center'>New User? <a href='register.php'>Click here!</a></div><br>
                                                </p>
                                                <div id="r_copy"><div id="logForm_errorloc"></div></div>
                                                </form>
			                                        <script language="JavaScript" type="text/javascript">
			                                        var frmvalidator  = new Validator("logForm");
			                                        frmvalidator.EnableOnPageErrorDisplaySingleBox();
			                                        frmvalidator.EnableMsgsTogether();   
			
			                                        frmvalidator.addValidation("loginid","req","Please enter your user id");
			                                        frmvalidator.addValidation("loginid","maxlen=30","Maximum length for TopCoder ID is 30");
			                                        frmvalidator.addValidation("loginid","minlen=6","Minimum length for TopCoder ID is 6");
			
			                                        frmvalidator.addValidation("pwd","req","Please enter your password");
			                                        frmvalidator.addValidation("pwd","minlen=5","Min length for password is 5");
			                                        </script>
                                        <?php
                                        }
                                        else{
                                                echo "Hi, You are logged in as  ", $_SESSION['name'];
                                                echo "<br><p><a href='logout.php'>Logout</a></p>";
                                        }
                                    ?>
                                    </div>
                                </li>
                                <!-- /login -->
                            </ul>
                        </div>
                        <!-- /sidebar 2nd container -->
                        </div>
                        <!-- /sidebar 1st container -->
                    </div>
                    <!-- /sidebar -->

				</div>
                <!-- /side wrap -->
                </div>
                <!-- /mid column wrap -->
                </div>
                <!-- /main wrapper -->

                <!-- clear main & sidebar sections -->
                <div class="clearcontent"></div>
                <!-- /clear main & sidebar sections -->

                <!-- footer -->
                <div id="footer">
    	            <p>GCT CSITA - iTeam<br>TopCoder uses <a href="http://ideone.com" target="_blank">Ideone API</a> &copy; by <a href="http://sphere-research.com" target="_blank">Sphere Research Labs</a></p>
                </div>
                <!-- /footer -->
                
                <!-- layout controls -->
                <div id="layoutcontrol">
        	        <a href="javascript:void(0);" class="setFont" title="Increase/Decrease text size"><span>SetTextSize</span></a>
            	    <a href="javascript:void(0);" class="setLiquid" title="Switch between full and fixed width"><span>SetPageWidth</span></a>
                </div>
                <!-- /layout controls -->
               
            </div>
            <!-- /page -->
        </div>
        </div>
        <!-- /page wrappers -->
	
	</body>
</html>     
