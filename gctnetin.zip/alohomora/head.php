<head>
    <title>Alohomora - Online Treasure Hunt</title>
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="forum_style.css">
    <link rel="icon" type="image/ico" href="images/favicon.ico">
    <script language="JavaScript" src="js/gen_validatorv4.js" type="text/javascript"></script>
    <script language="JavaScript" src="js/jquery.min.js" type="text/javascript"></script>
</head>